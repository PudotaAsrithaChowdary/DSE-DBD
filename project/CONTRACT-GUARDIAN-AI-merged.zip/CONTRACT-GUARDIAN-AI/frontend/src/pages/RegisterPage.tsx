export { RegisterPage } from './LoginPage';
